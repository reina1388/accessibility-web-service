const SEVERITY_LABEL = { critical: '심각', serious: '높음', moderate: '보통', minor: '낮음' };
const SEVERITY_ORDER = { critical: 0, serious: 1, moderate: 2, minor: 3 };

document.getElementById('print-btn').addEventListener('click', () => window.print());

chrome.storage.local.get('lastReport', (data) => {
  const report = data.lastReport;
  const root = document.getElementById('report-root');

  if (!report) {
    root.innerHTML = '<p>표시할 보고서 데이터가 없습니다. 사이드패널에서 검사를 먼저 실행해주세요.</p>';
    return;
  }

  root.innerHTML = '';
  root.appendChild(buildHeader(report));
  root.appendChild(buildExecSummary(report));
  root.appendChild(buildMatrixSection(report));
  root.appendChild(buildActionPlanSection(report));
  root.appendChild(buildDetailSection(report));
  root.appendChild(buildFooter(report));

  document.title = `웹 접근성 감사 보고서 - ${report.pageTitle || report.pageUrl}`;
});

function buildHeader(report) {
  const el = document.createElement('header');
  el.className = 'report__header';
  const genDate = new Date(report.generatedAt).toLocaleString('ko-KR');
  el.innerHTML = `
    <div class="report__eyebrow">AI 웹 접근성 감사 보고서</div>
    <h1>${escapeHtml(report.pageTitle || '(제목 없음)')}</h1>
    <div class="report__meta">
      <div>검사 대상: ${escapeHtml(report.pageUrl)}</div>
      <div>생성 일시: ${genDate}</div>
      <div>검사 기준: WCAG 2.1/2.2 (axe-core) · KWCAG 2.1 매핑 · AI(Claude/Gemini/OpenAI) 에이전트 자율 검증 포함</div>
    </div>
  `;
  return el;
}

function buildExecSummary(report) {
  const el = document.createElement('section');
  el.className = 'exec-summary';

  const counts = { critical: 0, serious: 0, moderate: 0, minor: 0 };
  report.findings.forEach((f) => {
    if (counts[f.severity] !== undefined) counts[f.severity] += 1;
  });
  const verifiedCount = report.findings.filter((f) => f.verified).length;
  const total = report.findings.length;

  const summaryText = total === 0
    ? '이 페이지에서 axe-core 기준 접근성 위반 항목이 발견되지 않았습니다.'
    : `이 페이지에서 총 ${total}건의 웹 접근성 문제가 발견되었습니다. 이 중 심각(critical) ${counts.critical}건, 높음(serious) ${counts.serious}건은 스크린리더 및 키보드 사용자의 이용에 직접적인 지장을 줄 수 있어 우선 조치가 필요합니다.`;

  el.innerHTML = `
    <div class="grade-badge grade-${report.grade.toLowerCase()}">
      <span class="grade-badge__letter">${report.grade}</span>
      <span class="grade-badge__score">${report.score}/100</span>
    </div>
    <div class="exec-summary__text">
      <div class="exec-summary__chips">
        ${Object.entries(counts)
          .filter(([, c]) => c > 0)
          .map(([sev, c]) => `<span class="chip chip--${sev}">${SEVERITY_LABEL[sev]} ${c}건</span>`)
          .join('')}
      </div>
      <p>${summaryText}</p>
      ${
        verifiedCount > 0
          ? `<div class="callout">✓ AI가 실제로 검증한 즉시 적용 가능한 수정안: ${verifiedCount}건 (아래 "실행 계획" 참고)</div>`
          : `<div class="callout callout--empty">이번 검사에서는 자동 검증(verify_fix)을 거친 수정안이 없습니다.</div>`
      }
    </div>
  `;
  return el;
}

function buildMatrixSection(report) {
  const el = document.createElement('section');
  el.className = 'section';

  const byRef = new Map();
  report.findings.forEach((f) => {
    const key = f.kwcagRef || '관련 KWCAG 원칙 미상';
    if (!byRef.has(key)) byRef.set(key, { count: 0, titles: new Set() });
    const entry = byRef.get(key);
    entry.count += 1;
    entry.titles.add(f.title);
  });

  const rows = Array.from(byRef.entries())
    .map(
      ([ref, info]) => `
      <tr>
        <td>${escapeHtml(ref)}</td>
        <td>${Array.from(info.titles).map(escapeHtml).join(', ')}</td>
        <td>${info.count}건</td>
        <td><span class="matrix-status matrix-status--fail">위반</span></td>
      </tr>`
    )
    .join('');

  el.innerHTML = `
    <h2>KWCAG 준수 매트릭스</h2>
    <p class="section__disclaimer">
      ※ 이 표는 이번 검사에서 발견된 위반 항목을 기준으로 작성되었으며, KWCAG 전 조항에 대한
      전수 검사 결과가 아닙니다. 표에 없는 조항은 "위반 없음"이 아니라 "이번 자동 검사 범위에
      포함되지 않음"을 의미할 수 있습니다. 공식 인증이 필요한 경우 전문 심사기관의 검토를 받으세요.
    </p>
    <table class="matrix-table">
      <thead>
        <tr><th>관련 KWCAG 원칙</th><th>세부 항목</th><th>발견 건수</th><th>상태</th></tr>
      </thead>
      <tbody>${rows || '<tr><td colspan="4">발견된 위반 항목이 없습니다.</td></tr>'}</tbody>
    </table>
  `;
  return el;
}

function buildActionPlanSection(report) {
  const el = document.createElement('section');
  el.className = 'section';

  const sorted = [...report.findings].sort(
    (a, b) => (SEVERITY_ORDER[a.severity] ?? 9) - (SEVERITY_ORDER[b.severity] ?? 9)
  );

  const items = sorted
    .map(
      (f) => `
      <div class="action-item">
        ${
          f.screenshotDataUrl
            ? `<img class="action-item__thumb" src="${f.screenshotDataUrl}" alt="${escapeHtml(f.title)} 문제 요소 스크린샷" />`
            : '<div class="action-item__thumb"></div>'
        }
        <div class="action-item__body">
          <div class="action-item__title-row">
            <span class="chip chip--${f.severity}">${SEVERITY_LABEL[f.severity] || f.severity}</span>
            <span class="action-item__title">${escapeHtml(f.title)}</span>
            ${f.verified ? '<span class="verified-tag">✓ AI 검증됨</span>' : ''}
          </div>
          <p class="action-item__fix">${escapeHtml(f.howToFix)}</p>
        </div>
      </div>`
    )
    .join('');

  el.innerHTML = `
    <h2>실행 계획 (우선순위순)</h2>
    ${items || '<p>조치할 항목이 없습니다.</p>'}
  `;
  return el;
}

function buildDetailSection(report) {
  const el = document.createElement('section');
  el.className = 'section';

  const cards = report.findings
    .map(
      (f) => `
      <div class="detail-card">
        <div class="detail-card__header">
          <span class="chip chip--${f.severity}">${SEVERITY_LABEL[f.severity] || f.severity}</span>
          <span class="detail-card__title">${escapeHtml(f.title)}</span>
          ${f.kwcagRef ? `<span class="detail-card__ref">${escapeHtml(f.kwcagRef)}</span>` : ''}
          ${f.verified ? '<span class="verified-tag">✓ AI 검증됨</span>' : ''}
        </div>
        <p class="detail-card__label">무엇이 문제인가요</p>
        <p class="detail-card__text">${escapeHtml(f.explanation)}</p>
        <p class="detail-card__label">어떻게 수정하나요</p>
        <p class="detail-card__text">${escapeHtml(f.howToFix)}</p>
        ${f.selector ? `<code class="detail-card__selector">${escapeHtml(f.selector)}</code>` : ''}
        ${f.screenshotDataUrl ? `<img class="detail-card__img" src="${f.screenshotDataUrl}" alt="${escapeHtml(f.title)} 문제 요소 스크린샷" />` : ''}
      </div>`
    )
    .join('');

  el.innerHTML = `
    <h2>상세 진단 목록 (개발자용)</h2>
    ${cards || '<p>발견된 위반 항목이 없습니다.</p>'}
  `;
  return el;
}

function buildFooter() {
  const el = document.createElement('footer');
  el.className = 'report__footer';
  el.innerHTML = `
    이 보고서는 axe-core(WCAG 2.1/2.2 규칙) 자동 검사와 AI(Claude/Gemini/OpenAI) 에이전트의 KWCAG 매핑·검증을
    기반으로 자동 생성되었습니다. 준수 점수/등급은 자체 산정 지표이며 공식 KWCAG 인증 점수가
    아닙니다. 색상 인지, 콘텐츠의 의미적 적절성 등 자동 판별이 어려운 항목은 포함되지 않을 수
    있으므로, 최종 준수 여부는 전문 심사기관 또는 수동 검토와 함께 확인하시기 바랍니다.
  `;
  return el;
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
