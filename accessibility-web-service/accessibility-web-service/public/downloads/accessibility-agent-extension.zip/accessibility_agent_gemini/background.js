// 확장 프로그램 아이콘 클릭 시 사이드패널이 열리도록 설정
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((err) => console.error('sidePanel 설정 오류:', err));

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const handlers = {
    RUN_AXE: () => runAxeOnTab(msg.tabId, msg.options || {}),
    INSPECT_ELEMENT: () => inspectElementOnTab(msg.tabId, msg.selector),
    VERIFY_FIX: () => verifyFixOnTab(msg.tabId, msg.payload),
    HIGHLIGHT_NODE: () => highlightNodeOnTab(msg.tabId, msg.target),
    CAPTURE_ELEMENT_SCREENSHOT: () => captureElementScreenshot(msg.tabId, msg.selector),
  };

  const handler = handlers[msg.type];
  if (!handler) return false;

  handler()
    .then((result) => sendResponse({ ok: true, result }))
    .catch((err) => sendResponse({ ok: false, error: err.message }));
  return true; // 비동기 응답을 위해 true 반환
});

async function ensureAxeInjected(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ['lib/axe.min.js'],
  });
}

// ── 도구 1: axe_scan ─────────────────────────────────────────
// selector로 검사 범위를 좁히거나, runOnly로 특정 규칙만 실행 가능
async function runAxeOnTab(tabId, options) {
  await ensureAxeInjected(tabId);

  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    func: async (opts) => {
      const context = opts.selector
        ? document.querySelector(opts.selector) || document
        : document;
      const axeOptions = { resultTypes: ['violations'] };
      if (opts.runOnly && opts.runOnly.length) {
        axeOptions.runOnly = opts.runOnly;
      }
      // eslint-disable-next-line no-undef
      const results = await axe.run(context, axeOptions);
      return results;
    },
    args: [options],
  });

  return result;
}

// ── 도구 2: inspect_element ─────────────────────────────────
// 특정 요소의 outerHTML, 속성, 주요 계산 스타일, 위치를 반환
async function inspectElementOnTab(tabId, selector) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    func: (sel) => {
      const el = document.querySelector(sel);
      if (!el) return { found: false };

      const cs = getComputedStyle(el);
      const rect = el.getBoundingClientRect();
      const attributes = {};
      for (const attr of el.attributes) attributes[attr.name] = attr.value;

      return {
        found: true,
        outerHtml: el.outerHTML.slice(0, 500),
        attributes,
        computedStyle: {
          color: cs.color,
          backgroundColor: cs.backgroundColor,
          fontSize: cs.fontSize,
          fontWeight: cs.fontWeight,
        },
        rect: { width: rect.width, height: rect.height },
      };
    },
    args: [selector],
  });

  return result;
}

// ── 도구 3: verify_fix ───────────────────────────────────────
// 수정안을 "임시로" 적용 → 해당 규칙만 재검사 → 결과와 무관하게 즉시 원복
// 실제 페이지/코드에는 영구적인 변경을 남기지 않음
async function verifyFixOnTab(tabId, payload) {
  await ensureAxeInjected(tabId);

  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    func: async ({ selector, ruleId, attributes, styles }) => {
      const el = document.querySelector(selector);
      if (!el) return { applied: false, reason: '요소를 찾을 수 없습니다.' };

      // 원본 상태 백업
      const originalAttrs = {};
      Object.keys(attributes || {}).forEach((key) => {
        originalAttrs[key] = el.getAttribute(key);
      });
      const originalStyleText = el.style.cssText;

      // 임시 적용
      Object.entries(attributes || {}).forEach(([key, value]) => {
        el.setAttribute(key, value);
      });
      Object.entries(styles || {}).forEach(([key, value]) => {
        el.style[key] = value;
      });

      let stillViolating = false;
      let error = null;
      try {
        // eslint-disable-next-line no-undef
        const results = await axe.run(document, { runOnly: [ruleId], resultTypes: ['violations'] });
        const rule = results.violations.find((v) => v.id === ruleId);
        stillViolating = !!rule && rule.nodes.some((n) => {
          try {
            return document.querySelector(n.target[0]) === el;
          } catch (e) {
            return false;
          }
        });
      } catch (e) {
        error = e.message;
      }

      // 원복
      Object.entries(originalAttrs).forEach(([key, value]) => {
        if (value === null) el.removeAttribute(key);
        else el.setAttribute(key, value);
      });
      el.style.cssText = originalStyleText;

      return { applied: true, resolved: !stillViolating, error };
    },
    args: [payload],
  });

  return result;
}

async function highlightNodeOnTab(tabId, targetSelector) {
  await chrome.scripting.executeScript({
    target: { tabId },
    func: (selector) => {
      try {
        const el = document.querySelector(selector);
        if (!el) return;
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        const prevOutline = el.style.outline;
        const prevOffset = el.style.outlineOffset;
        el.style.outline = '3px solid #e0491d';
        el.style.outlineOffset = '2px';
        setTimeout(() => {
          el.style.outline = prevOutline;
          el.style.outlineOffset = prevOffset;
        }, 2500);
      } catch (e) {
        console.warn('요소를 찾을 수 없습니다:', selector, e);
      }
    },
    args: [targetSelector],
  });
}

// ── 도구: 보고서용 스크린샷 증거 캡처 ──────────────────────────
// 1) 요소를 화면 중앙으로 스크롤 + 빨간 테두리 표시
// 2) 탭 전체를 캡처
// 3) 서비스워커의 OffscreenCanvas로 요소 주변만 잘라냄
// 4) 하이라이트 원복
async function captureElementScreenshot(tabId, selector) {
  const tab = await chrome.tabs.get(tabId);

  const [{ result: rectInfo }] = await chrome.scripting.executeScript({
    target: { tabId },
    func: (sel) => {
      const el = document.querySelector(sel);
      if (!el) return null;
      el.scrollIntoView({ block: 'center', inline: 'center' });
      el.style.outline = '3px solid #e0491d';
      el.style.outlineOffset = '2px';
      el.dataset.a11yCaptureHighlight = '1';
      const rect = el.getBoundingClientRect();
      return {
        x: rect.x,
        y: rect.y,
        width: rect.width,
        height: rect.height,
        dpr: window.devicePixelRatio || 1,
      };
    },
    args: [selector],
  });

  if (!rectInfo || rectInfo.width === 0) {
    return { error: '요소를 찾을 수 없거나 화면에 표시되지 않습니다.' };
  }

  // 스크롤/리페인트가 끝나길 잠깐 대기
  await new Promise((resolve) => setTimeout(resolve, 350));

  let dataUrl;
  try {
    dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
  } finally {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: (sel) => {
        const el = document.querySelector(sel);
        if (el && el.dataset.a11yCaptureHighlight) {
          el.style.outline = '';
          el.style.outlineOffset = '';
          delete el.dataset.a11yCaptureHighlight;
        }
      },
      args: [selector],
    });
  }

  const blob = await (await fetch(dataUrl)).blob();
  const bitmap = await createImageBitmap(blob);

  const dpr = rectInfo.dpr;
  const padding = 16; // CSS px 기준 여유 공간
  const cropX = Math.max(0, (rectInfo.x - padding) * dpr);
  const cropY = Math.max(0, (rectInfo.y - padding) * dpr);
  const cropW = Math.min(bitmap.width - cropX, (rectInfo.width + padding * 2) * dpr);
  const cropH = Math.min(bitmap.height - cropY, (rectInfo.height + padding * 2) * dpr);

  if (cropW <= 0 || cropH <= 0) {
    return { error: '요소가 현재 화면 밖에 있어 캡처할 수 없습니다.' };
  }

  const canvas = new OffscreenCanvas(cropW, cropH);
  const ctx = canvas.getContext('2d');
  ctx.drawImage(bitmap, cropX, cropY, cropW, cropH, 0, 0, cropW, cropH);
  const croppedBlob = await canvas.convertToBlob({ type: 'image/png' });
  const screenshotDataUrl = await blobToDataUrl(croppedBlob);

  return { screenshotDataUrl };
}

async function blobToDataUrl(blob) {
  const buffer = await blob.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
  return `data:image/png;base64,${btoa(binary)}`;
}
