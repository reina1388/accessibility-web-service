# 웹 접근성 검증 AI Agent (Chrome 확장 프로그램)

현재 열려 있는 웹페이지의 DOM을 [axe-core](https://github.com/dequelabs/axe-core)로 검사하고,
AI(Claude/Gemini/OpenAI 중 선택)가 위반 항목을 **KWCAG 2.1** 기준 언어로 설명 + 자연어 수정 가이드를 생성해주는
사이드패널 방식의 크롬 확장 프로그램입니다.

## 아키텍처 (tool-use 에이전트 루프)

이 확장 프로그램은 "axe 실행 → AI가 설명만 생성"하는 고정 파이프라인이 아니라,
**AI가 도구 목록을 받아 스스로 어떤 도구를 언제 쓸지 판단하고, 결과를 검증하며 반복(loop)하는
진짜 tool-use 에이전트**로 동작합니다.

```
[사용자가 "현재 페이지 검사" 클릭]
        │
        ▼
[AI에게 초기 지시 + 5개 도구 전달] ─── 최대 8턴 반복 ───┐
        │                                                  │
        ├─▶ axe_scan          : 페이지(전체/특정 영역) 검사 │
        ├─▶ inspect_element   : 요소의 실제 스타일/속성 확인│
        ├─▶ compute_contrast  : 명도 대비 직접 계산         │
        ├─▶ verify_fix        : 수정안 임시 적용→재검사→즉시 원복
        │      (실제로 문제가 해결되는지 AI가 스스로 검증)│
        │                                                  │
        └─▶ finish_report 호출 시 루프 종료 ◀───────────────┘
        │
        ▼
[사이드패널] "에이전트 활동 로그"에 각 도구 호출 과정을 실시간 표시 +
             finish_report의 findings를 카드 UI로 렌더링 (검증된 항목은 "✓ 검증됨" 배지)
```

**도구 목록** (`sidepanel.js`의 `TOOLS` 상수 참고):

| 도구 | 역할 | 실제 페이지 변경 여부 |
|---|---|---|
| `axe_scan` | axe-core 검사 실행 (전체/특정 선택자/특정 규칙) | 없음 (읽기 전용) |
| `inspect_element` | 요소의 outerHTML, 속성, 계산된 스타일, 크기 조회 | 없음 (읽기 전용) |
| `compute_contrast` | 색상 대비(WCAG contrast ratio) 순수 계산 | 없음 (DOM 접근 없음) |
| `verify_fix` | 속성/스타일을 **임시로** 적용 → 해당 규칙만 재검사 → **즉시 원복** | 없음 (자동 원복, 영구 변경 없음) |
| `finish_report` | 최종 보고서 제출, 루프 종료 신호 | - |

**종료 조건**: AI가 `finish_report`를 호출하면 즉시 종료됩니다. 8턴 안에 호출하지 않으면
"최대 반복 횟수 안에 보고서를 완성하지 못했습니다" 오류로 안전하게 중단됩니다 (무한 루프 방지).

**비용/속도 참고**: 기존 방식은 페이지당 API 호출이 1회였지만, 이 구조는 도구 호출 턴마다
API를 호출하므로 최대 8회까지 호출될 수 있습니다. 정확도/자율성과 비용 사이의 트레이드오프이니,
비용이 부담되면 `sidepanel.js`의 `MAX_TURNS` 값을 낮추세요.

## 멀티 AI 공급자 지원 (Claude / Gemini / OpenAI)

옵션 페이지에서 세 공급자 중 하나를 선택해 사용할 수 있습니다. 한 곳이 사용량 한도(429)에 걸리면
다른 공급자로 바꿔서 계속 검사를 진행할 수 있어요.

내부적으로는 공급자에 상관없는 **공통 transcript 형식**을 사용하고, 각 공급자의 어댑터가
이를 자기 API 형식으로 변환합니다 (`sidepanel.js`의 `ClaudeAdapter` / `GeminiAdapter` / `OpenAIAdapter`).

| 공급자 | 엔드포인트 | 도구 호출 방식 | 도구 스키마 |
|---|---|---|---|
| Claude | `api.anthropic.com/v1/messages` | `tool_use` / `tool_result` | JSON Schema 그대로 |
| Gemini | `generativelanguage.googleapis.com/.../generateContent` | `functionCall` / `functionResponse` | 대문자 Type으로 자동 변환 |
| OpenAI | `api.openai.com/v1/chat/completions` | `tool_calls` / `role: 'tool'` | JSON Schema 그대로 |

에이전트 루프(`runAgentLoop`), 도구 실행(`executeTool`), 캐시, 감사 보고서 등 나머지 로직은
공급자와 무관하게 완전히 동일하게 동작합니다 — 바뀌는 건 "API를 어떻게 호출하는가" 뿐입니다.

## 개발 환경 설정 (선택 사항, VSCode 편집 경험 개선용)

이 프로젝트는 **순수 JavaScript**이며 빌드/컴파일 과정이 없습니다. 따라서 `package.json`,
`jsconfig.json` 모두 **크롬에서 실제로 동작하는 것과는 무관**하고, VSCode에서
`chrome.*` API 자동완성을 받기 위한 개발 편의용 파일입니다. 없어도 확장 프로그램은 정상 동작합니다.

```bash
npm install
```

위 명령을 실행하면 `@types/chrome`(타입 힌트용)과 `axe-core`가 `node_modules`에 설치됩니다.
axe-core를 실제로 확장 프로그램에서 쓰려면 여전히 `lib/axe.min.js`로 파일을 복사해 넣어야 합니다
(Chrome 확장은 `node_modules`를 직접 참조하지 않습니다):

```bash
cp node_modules/axe-core/axe.min.js lib/axe.min.js
```

## 감사 보고서 생성 (PDF)

검사가 끝나면 결과 아래 **"📄 감사 보고서 생성 (PDF)"** 버튼이 나타납니다. 클릭하면:

1. 발견된 위반 항목마다 해당 요소로 스크롤 → 빨간 테두리 표시 → 화면 캡처 → 요소 주변만 잘라내어
   **스크린샷 증거**를 자동 수집합니다 (서비스워커의 OffscreenCanvas로 크롭, 별도 라이브러리 불필요).
2. 새 탭에서 `report.html`이 열리고, 다음 구성으로 보고서가 렌더링됩니다.
   - **경영진 요약**: 준수 점수(0~100)와 등급(A~D), 심각도별 건수, "AI가 실제로 검증한 즉시 조치
     가능 항목" 콜아웃
   - **KWCAG 준수 매트릭스**: 발견된 위반을 관련 KWCAG 원칙별로 그룹화한 표 (전수 검사가 아님을
     명시하는 안내 문구 포함)
   - **실행 계획**: 심각도 순으로 정렬된 조치 목록, 스크린샷 썸네일과 함께 표시, `verify_fix`로
     검증된 항목엔 "✓ AI 검증됨" 태그
   - **상세 진단 목록**: 개발자용 전체 설명 + 큰 스크린샷 + CSS 선택자
3. 상단 **"🖨️ 인쇄 / PDF로 저장"** 버튼(또는 브라우저 인쇄 단축키)을 누르고 인쇄 대상을
   **"PDF로 저장"**으로 선택하면 파일로 저장됩니다. (별도 PDF 라이브러리 없이 브라우저 내장
   인쇄 기능을 사용하므로 추가 설치가 필요 없습니다.)

> 점수/등급은 심각도 가중치 기반의 자체 산정 지표이며, 공식 KWCAG 인증 점수가 아닙니다.
> 스크린샷은 `chrome.tabs.captureVisibleTab` + `activeTab` 권한으로 캡처되며, 캡처된 이미지는
> `chrome.storage.local`에만 저장되고 외부로 전송되지 않습니다.

## 설명 캐시 (규칙 + 도메인 단위)

같은 사이트에서 같은 axe 규칙(예: `image-alt`)을 다시 만나면, AI가 설명을 처음부터 다시 작성하지 않고
**이전에 저장해둔 설명을 재사용**합니다. 도구가 2개 추가되었습니다.

- `check_cache(ruleId)`: 현재 사이트(도메인)에 이 규칙에 대한 저장된 설명이 있는지 확인
- `save_explanation_cache(...)`: 새로 작성한 설명(title/kwcagRef/explanation/howToFix)을 저장

**캐시되지 않는 것**: `verify_fix`(실제 검증)는 페이지의 실제 DOM에 따라 결과가 달라질 수 있어 캐시하지 않고
항상 새로 실행합니다. 캐시는 "설명 문구"에만 적용되고, "이 페이지에서 실제로 통하는지 검증"에는 적용되지 않습니다.

- **저장 위치**: `chrome.storage.local`, 키 형식 `explainCache:{버전}:{도메인}:{ruleId}`
- **버전 관리**: 프롬프트나 매핑 로직을 바꾸면 `sidepanel.js`의 `CACHE_VERSION` 값을 올리세요. 버전이 다르면
  자동으로 새 캐시로 취급되어 예전 설명이 재사용되지 않습니다.
- **초기화**: 옵션 페이지에서 저장된 캐시 개수를 확인하고 "캐시 전체 초기화" 버튼으로 언제든 지울 수 있습니다.

## 설치 및 실행 방법

### 1. axe-core 라이브러리 준비 (필수)
크롬 확장(Manifest V3)은 원격 스크립트를 실행할 수 없어 axe-core를 직접 파일로 포함해야 합니다.
`lib/PUT_AXE_CORE_HERE.txt` 파일의 안내를 따라 `lib/axe.min.js` 파일을 받아 넣어주세요.

```bash
npm install axe-core
cp node_modules/axe-core/axe.min.js lib/axe.min.js
```

### 2. 크롬에 확장 프로그램 로드
1. 크롬 주소창에 `chrome://extensions` 입력
2. 우측 상단 "개발자 모드" 켜기
3. "압축해제된 확장 프로그램을 로드합니다" 클릭
4. 이 프로젝트 폴더(`accessibility-agent`) 선택

### 3. AI 공급자 및 API 키 설정
1. 확장 아이콘 우클릭 → "옵션" (또는 사이드패널 하단 "API 키 / 모델 설정" 링크)
2. **AI 공급자** 드롭다운에서 Gemini / Claude / OpenAI 중 선택
3. 선택한 공급자의 API 키 입력 (아래에서 발급)
   - **Gemini**: [Google AI Studio](https://aistudio.google.com/apikey)
   - **Claude**: [Anthropic Console](https://console.anthropic.com/)
   - **OpenAI**: [OpenAI Platform](https://platform.openai.com/api-keys)
4. 사용할 모델 선택 후 저장

세 공급자의 키/모델은 각각 별도로 저장되므로, 나중에 드롭다운에서 공급자만 바꿔도 이전에 입력했던 키가 남아있습니다. 한 공급자가 사용량 한도(429 오류)에 걸리면 옵션에서 다른 공급자로 바로 전환해서 계속 쓸 수 있습니다.

> API 키는 `chrome.storage.local`에만 저장되며, 선택한 공급자의 API 서버 외에는 어디로도 전송되지 않습니다.

### 4. 사용하기
1. 검사하고 싶은 웹페이지로 이동
2. 확장 아이콘 클릭 → 사이드패널 열림
3. "현재 페이지 검사" 클릭
4. 위반 항목 카드를 펼쳐서 문제 설명 + 수정 방법 확인
5. "위치 표시" 클릭 시 페이지에서 해당 요소가 잠깐 강조 표시됨 (스크롤 이동 + 빨간 테두리)

## 알아두어야 할 점

- **실제 페이지/코드에 영구적인 자동 수정은 하지 않습니다.** `verify_fix` 도구가 검증을 위해
  속성/스타일을 잠깐 바꾸긴 하지만, 검사 직후 즉시 원래 값으로 되돌립니다. 최종 결과물은
  "문제점 설명 + 자연어 수정 가이드"이며, 실제 코드를 고치려면 사람이 직접 반영해야 합니다.
- **axe-core는 WCAG 2.0/2.1/2.2 규칙 기반**입니다. KWCAG는 WCAG와 상당 부분 유사하지만
  완전히 동일하지는 않아서, AI가 "가장 근접한 KWCAG 원칙"으로 매핑해 설명합니다.
  법적/심사 목적의 정식 KWCAG 준수 검증이 필요하다면 반드시 전문 심사기관의 검토를 함께 받으세요.
- 단일 탭(현재 보고 있는 페이지) 대상입니다. 여러 페이지 일괄 검사가 필요하면
  별도의 URL 리스트 크롤링 모드 추가를 고려하세요.
- axe-core가 잡아내지 못하는 항목(콘텐츠의 의미적 적절성, 색상만으로 정보를 전달하는지 등
  자동 판별이 어려운 항목)도 있으므로, 수동 검토를 완전히 대체하지는 않습니다.

## 파일 구조

```
accessibility-agent/
├── manifest.json        # 확장 프로그램 설정 (Manifest V3)
├── background.js         # axe-core 주입/실행, 요소 하이라이트
├── sidepanel.html/css/js  # 검사 결과를 보여주는 메인 UI
├── options.html/js       # API 키 / 모델 설정 화면
├── report.html/css/js     # 감사 보고서(PDF) 페이지
├── lib/axe.min.js        # (직접 추가 필요) axe-core 라이브러리
└── icons/                # 확장 프로그램 아이콘
```
