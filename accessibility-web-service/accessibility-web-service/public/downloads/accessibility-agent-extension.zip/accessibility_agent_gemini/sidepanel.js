const runBtn = document.getElementById('run-btn');
const statusEl = document.getElementById('status');
const summaryEl = document.getElementById('summary');
const resultsEl = document.getElementById('results');
const agentLogEl = document.getElementById('agent-log');
const agentLogListEl = document.getElementById('agent-log-list');
const agentLogCountEl = document.getElementById('agent-log-count');
const reportSectionEl = document.getElementById('report-section');
const reportBtn = document.getElementById('report-btn');

let lastFindings = [];
let lastTabInfo = null;

const SEVERITY_LABEL = {
  critical: '심각',
  serious: '높음',
  moderate: '보통',
  minor: '낮음',
};

const PROVIDER_LABEL = { claude: 'Claude', gemini: 'Gemini', openai: 'OpenAI' };

const MAX_TURNS = 8;
const CACHE_VERSION = 'v1';

const TOOLS = [
  {
    name: 'axe_scan',
    description:
      '현재 탭 페이지 전체(또는 특정 CSS 선택자 범위)에 대해 axe-core 접근성 검사를 실행합니다. 위반 항목 목록(id, impact, description, help, nodes)을 반환합니다.',
    input_schema: {
      type: 'object',
      properties: {
        selector: {
          type: 'string',
          description: '검사 범위를 좁힐 CSS 선택자. 생략하면 문서 전체를 검사합니다.',
        },
        runOnly: {
          type: 'array',
          items: { type: 'string' },
          description: "특정 axe rule id만 실행하고 싶을 때 지정 (예: ['color-contrast']).",
        },
      },
    },
  },
  {
    name: 'inspect_element',
    description:
      '지정한 CSS 선택자에 해당하는 요소의 outerHTML, 속성, 주요 계산 스타일(color, background-color, font-size, font-weight), 크기를 반환합니다.',
    input_schema: {
      type: 'object',
      properties: { selector: { type: 'string' } },
      required: ['selector'],
    },
  },
  {
    name: 'compute_contrast',
    description: '두 색상(hex 또는 rgb 문자열)의 WCAG 명도 대비(contrast ratio)를 계산합니다.',
    input_schema: {
      type: 'object',
      properties: {
        foreground: { type: 'string' },
        background: { type: 'string' },
      },
      required: ['foreground', 'background'],
    },
  },
  {
    name: 'verify_fix',
    description:
      "제안한 수정안을 페이지에 '임시로' 적용한 뒤 해당 axe rule만 재검사하고, 검사가 끝나면 즉시 원래 상태로 되돌립니다. 실제 페이지나 코드에는 영구적인 변경을 남기지 않습니다. 확신이 있는 수정안은 반드시 이 도구로 검증한 뒤 보고서에 포함하세요.",
    input_schema: {
      type: 'object',
      properties: {
        selector: { type: 'string' },
        ruleId: { type: 'string', description: '재검사할 axe rule id' },
        attributes: {
          type: 'object',
          description: "임시로 적용할 속성 key-value (예: {\"alt\": \"로그인 버튼\"})",
        },
        styles: {
          type: 'object',
          description: '임시로 적용할 인라인 스타일 key-value',
        },
      },
      required: ['selector', 'ruleId'],
    },
  },
  {
    name: 'check_cache',
    description:
      '이 도구를 사용해 현재 사이트(도메인)에서 이 axe rule에 대한 설명을 예전에 이미 작성해 저장해둔 적이 있는지 확인하세요. 있다면(cached: true) 그 설명을 그대로 재사용하고 다시 작성하지 마세요. 새로운 텍스트를 만드는 데는 비용이 들지만, 캐시 확인/저장은 비용이 들지 않습니다.',
    input_schema: {
      type: 'object',
      properties: { ruleId: { type: 'string' } },
      required: ['ruleId'],
    },
  },
  {
    name: 'save_explanation_cache',
    description:
      '새로 작성한 설명(title, kwcagRef, explanation, howToFix)을 이 사이트(도메인)의 이 axe rule에 대한 캐시로 저장합니다. 나중에 같은 사이트에서 같은 규칙을 다시 만나면 check_cache로 재사용할 수 있습니다. selector처럼 특정 요소에만 해당하는 정보는 저장하지 말고, 규칙 자체에 대한 일반적인 설명만 저장하세요.',
    input_schema: {
      type: 'object',
      properties: {
        ruleId: { type: 'string' },
        title: { type: 'string' },
        kwcagRef: { type: 'string' },
        explanation: { type: 'string' },
        howToFix: { type: 'string' },
      },
      required: ['ruleId', 'title', 'explanation', 'howToFix'],
    },
  },
  {
    name: 'finish_report',
    description:
      '검사와 (가능한 경우) 검증이 끝나면 이 도구를 호출해 최종 보고서를 제출하세요. 이 호출 이후에는 다른 도구를 호출하지 않습니다.',
    input_schema: {
      type: 'object',
      properties: {
        findings: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              ruleId: { type: 'string' },
              title: { type: 'string' },
              severity: { type: 'string', enum: ['critical', 'serious', 'moderate', 'minor'] },
              kwcagRef: { type: 'string' },
              selector: { type: 'string' },
              explanation: { type: 'string' },
              howToFix: { type: 'string' },
              verified: {
                type: 'boolean',
                description: 'verify_fix 도구로 실제 해결을 확인했는지 여부',
              },
            },
            required: ['ruleId', 'title', 'severity', 'explanation', 'howToFix'],
          },
        },
      },
      required: ['findings'],
    },
  },
];

// Gemini API는 JSON Schema의 소문자 type("object","string" 등) 대신
// 대문자 Type enum("OBJECT","STRING" 등)을 사용하므로 변환합니다.
function toGeminiSchema(schema) {
  if (!schema || typeof schema !== 'object') return schema;
  const out = {};
  if (schema.type) out.type = schema.type.toUpperCase();
  if (schema.description) out.description = schema.description;
  if (schema.enum) out.enum = schema.enum;
  if (schema.properties) {
    out.properties = {};
    for (const [key, val] of Object.entries(schema.properties)) {
      out.properties[key] = toGeminiSchema(val);
    }
  }
  if (schema.items) out.items = toGeminiSchema(schema.items);
  if (schema.required) out.required = schema.required;
  return out;
}

const AGENT_SYSTEM_PROMPT = `당신은 한국 웹 접근성(KWCAG 2.1) 진단 에이전트입니다.
주어진 도구를 사용해 현재 열려 있는 웹페이지를 스스로 조사하고, 발견한 문제를 검증한 뒤 최종 보고서를 제출하세요.

작업 방식:
1. axe_scan으로 전체 페이지를 검사해 위반 항목을 찾으세요.
2. 위반 항목마다 먼저 check_cache(ruleId)를 호출해 이 사이트에서 이미 작성해둔 설명이 있는지 확인하세요.
   - 캐시가 있으면(cached: true) 그 title/kwcagRef/explanation/howToFix를 그대로 재사용하세요. 다시 작성하지 마세요.
   - 캐시가 없으면 새로 작성한 뒤, save_explanation_cache로 저장해 다음에 재사용할 수 있게 하세요.
3. 색상 대비 관련 위반(캐시 여부와 무관하게 새로 등장한 요소라면)은 inspect_element로 실제 색상 값을 확인하고 compute_contrast로 직접 계산해 심각도를 재확인하세요.
4. 중요도가 critical 또는 serious인 항목 중 최소 1건 이상은 verify_fix로 수정안이 실제로 통하는지 검증하세요.
   (alt 속성 추가, aria-label 추가, 색상 값 변경 등 간단히 속성/스타일로 재현 가능한 경우에 한함)
   주의: verify_fix는 캐시된 설명이 있어도 반드시 이 페이지에서 새로 실행하세요. 검증 결과는 캐시하지 않습니다.
5. 확인이 끝나면 finish_report를 호출해 각 위반 항목마다 다음을 한국어로 작성하세요.
   - title: 짧은 제목
   - kwcagRef: 관련 KWCAG 2.1 원칙명 (정확히 대응 안 되면 "관련 원칙: ..." 형태로 근접 원칙 표기)
   - explanation: 스크린리더/키보드 사용자 등에게 왜 문제가 되는지 (2~3문장)
   - howToFix: 코드 스니펫 없이 자연어로 구체적인 수정 방법 (2~4문장)
   - verified: verify_fix로 검증했다면 true

주의: 최대 ${MAX_TURNS}번의 도구 호출 턴 안에 반드시 finish_report를 호출해 마무리하세요. 실제 페이지나 파일을 영구적으로 수정하지 마세요(verify_fix는 자동으로 원복됩니다).`;

// ── 공급자 어댑터 ──────────────────────────────────────────────
// 내부적으로는 공급자에 상관없는 공통 transcript 형식을 사용합니다:
//   { role: 'user', text }
//   { role: 'assistant', text?, toolCalls?: [{id, name, args}] }
//   { role: 'tool_results', results: [{id, name, output}] }
// 각 어댑터는 이 transcript를 자기 API 형식으로 변환해 호출하고,
// 응답을 다시 { text, toolCalls: [{id, name, args}] } 형태로 돌려줍니다.

const ClaudeAdapter = {
  buildTools() {
    return TOOLS.map((t) => ({ name: t.name, description: t.description, input_schema: t.input_schema }));
  },
  toMessages(transcript) {
    const messages = [];
    for (const entry of transcript) {
      if (entry.role === 'user') {
        messages.push({ role: 'user', content: entry.text });
      } else if (entry.role === 'assistant') {
        const content = [];
        if (entry.text) content.push({ type: 'text', text: entry.text });
        for (const tc of entry.toolCalls || []) {
          content.push({ type: 'tool_use', id: tc.id, name: tc.name, input: tc.args });
        }
        messages.push({ role: 'assistant', content });
      } else if (entry.role === 'tool_results') {
        const content = entry.results.map((r) => ({
          type: 'tool_result',
          tool_use_id: r.id,
          content: JSON.stringify(r.output),
        }));
        messages.push({ role: 'user', content });
      }
    }
    return messages;
  },
  async callModel(transcript, apiKey, model) {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true',
      },
      body: JSON.stringify({
        model,
        max_tokens: 4000,
        system: AGENT_SYSTEM_PROMPT,
        tools: this.buildTools(),
        messages: this.toMessages(transcript),
      }),
    });
    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Claude API 오류 (${response.status}): ${errText.slice(0, 200)}`);
    }
    const data = await response.json();
    const textBlock = data.content.find((b) => b.type === 'text');
    const toolCalls = data.content
      .filter((b) => b.type === 'tool_use')
      .map((b) => ({ id: b.id, name: b.name, args: b.input }));
    return { text: textBlock ? textBlock.text : '', toolCalls };
  },
};

const GeminiAdapter = {
  buildTools() {
    return [
      {
        functionDeclarations: TOOLS.map((t) => ({
          name: t.name,
          description: t.description,
          parameters: toGeminiSchema(t.input_schema),
        })),
      },
    ];
  },
  toContents(transcript) {
    const contents = [];
    for (const entry of transcript) {
      if (entry.role === 'user') {
        contents.push({ role: 'user', parts: [{ text: entry.text }] });
      } else if (entry.role === 'assistant') {
        const parts = [];
        if (entry.text) parts.push({ text: entry.text });
        for (const tc of entry.toolCalls || []) {
          parts.push({ functionCall: { name: tc.name, args: tc.args, id: tc.id } });
        }
        contents.push({ role: 'model', parts });
      } else if (entry.role === 'tool_results') {
        const parts = entry.results.map((r) => ({
          functionResponse: { name: r.name, id: r.id, response: r.output },
        }));
        contents.push({ role: 'user', parts });
      }
    }
    return contents;
  },
  async callModel(transcript, apiKey, model) {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
        body: JSON.stringify({
          system_instruction: { parts: [{ text: AGENT_SYSTEM_PROMPT }] },
          contents: this.toContents(transcript),
          tools: this.buildTools(),
          generationConfig: { maxOutputTokens: 4000 },
        }),
      }
    );
    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Gemini API 오류 (${response.status}): ${errText.slice(0, 200)}`);
    }
    const data = await response.json();
    const candidate = data.candidates && data.candidates[0];
    if (!candidate || !candidate.content) {
      throw new Error('Gemini 응답에서 유효한 candidate를 받지 못했습니다.');
    }
    const parts = candidate.content.parts || [];
    const textPart = parts.find((p) => p.text);
    const toolCalls = parts
      .filter((p) => p.functionCall)
      .map((p) => ({ id: p.functionCall.id, name: p.functionCall.name, args: p.functionCall.args }));
    return { text: textPart ? textPart.text : '', toolCalls };
  },
};

const OpenAIAdapter = {
  buildTools() {
    return TOOLS.map((t) => ({
      type: 'function',
      function: { name: t.name, description: t.description, parameters: t.input_schema },
    }));
  },
  toMessages(transcript) {
    const messages = [{ role: 'system', content: AGENT_SYSTEM_PROMPT }];
    for (const entry of transcript) {
      if (entry.role === 'user') {
        messages.push({ role: 'user', content: entry.text });
      } else if (entry.role === 'assistant') {
        const msg = { role: 'assistant', content: entry.text || null };
        if (entry.toolCalls && entry.toolCalls.length) {
          msg.tool_calls = entry.toolCalls.map((tc) => ({
            id: tc.id,
            type: 'function',
            function: { name: tc.name, arguments: JSON.stringify(tc.args) },
          }));
        }
        messages.push(msg);
      } else if (entry.role === 'tool_results') {
        for (const r of entry.results) {
          messages.push({ role: 'tool', tool_call_id: r.id, content: JSON.stringify(r.output) });
        }
      }
    }
    return messages;
  },
  async callModel(transcript, apiKey, model) {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages: this.toMessages(transcript),
        tools: this.buildTools(),
        tool_choice: 'auto',
        max_tokens: 4000,
      }),
    });
    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`OpenAI API 오류 (${response.status}): ${errText.slice(0, 200)}`);
    }
    const data = await response.json();
    const message = data.choices && data.choices[0] && data.choices[0].message;
    if (!message) throw new Error('OpenAI 응답에서 message를 받지 못했습니다.');
    const toolCalls = (message.tool_calls || []).map((tc) => ({
      id: tc.id,
      name: tc.function.name,
      args: safeJsonParse(tc.function.arguments),
    }));
    return { text: message.content || '', toolCalls };
  },
};

function safeJsonParse(str) {
  try {
    return JSON.parse(str);
  } catch (e) {
    return {};
  }
}

const ADAPTERS = { claude: ClaudeAdapter, gemini: GeminiAdapter, openai: OpenAIAdapter };

runBtn.addEventListener('click', handleRun);

async function handleRun() {
  resultsEl.innerHTML = '';
  summaryEl.hidden = true;
  agentLogEl.hidden = true;
  agentLogListEl.innerHTML = '';
  reportSectionEl.hidden = true;
  runBtn.disabled = true;

  try {
    const { provider, apiKey, model } = await getSettings();
    if (!apiKey) {
      setStatus(`먼저 설정에서 ${PROVIDER_LABEL[provider]} API 키를 입력해주세요.`);
      runBtn.disabled = false;
      return;
    }

    const tab = await getActiveTab();
    const domain = getDomainFromUrl(tab.url);
    agentLogEl.hidden = false;
    setStatus(`에이전트가 페이지를 조사하는 중... (${PROVIDER_LABEL[provider]})`);

    const findings = await runAgentLoop({ provider, apiKey, model, tabId: tab.id, domain });

    if (!findings.length) {
      setStatus('에이전트가 접근성 위반 항목을 발견하지 못했습니다.');
      runBtn.disabled = false;
      return;
    }

    renderSummary(findings);
    renderResults(findings, tab.id);
    setStatus(`검사 완료 · 총 ${findings.length}건의 위반 항목`);

    lastFindings = findings;
    lastTabInfo = { id: tab.id, url: tab.url, title: tab.title };
    reportSectionEl.hidden = false;
  } catch (err) {
    console.error(err);
    setStatus(`오류: ${err.message}`);
  } finally {
    runBtn.disabled = false;
  }
}

// ── 에이전트 루프 (공급자 무관, 공통 transcript 기반) ────────────
async function runAgentLoop({ provider, apiKey, model, tabId, domain }) {
  const adapter = ADAPTERS[provider];
  if (!adapter) throw new Error(`알 수 없는 공급자: ${provider}`);

  let transcript = [
    {
      role: 'user',
      text: '현재 열려 있는 페이지의 웹 접근성을 도구를 사용해 조사하고, KWCAG 2.1 기준으로 최종 보고서를 작성해줘.',
    },
  ];

  for (let turn = 1; turn <= MAX_TURNS; turn++) {
    const result = await adapter.callModel(transcript, apiKey, model);
    transcript.push({ role: 'assistant', text: result.text, toolCalls: result.toolCalls });

    if (!result.toolCalls || result.toolCalls.length === 0) {
      transcript.push({
        role: 'user',
        text: '계속 진행하려면 도구를 호출하거나, 조사가 끝났다면 finish_report 도구로 보고서를 제출해줘.',
      });
      continue;
    }

    const finishCall = result.toolCalls.find((tc) => tc.name === 'finish_report');
    if (finishCall) {
      logAgentStep('finish_report', '최종 보고서 작성 완료', true);
      return (finishCall.args && finishCall.args.findings) || [];
    }

    const toolResults = [];
    for (const tc of result.toolCalls) {
      logAgentStep(tc.name, describeToolCall(tc.name, tc.args));
      let output;
      try {
        output = await executeTool(tc.name, tc.args, tabId, domain);
      } catch (err) {
        output = { error: err.message };
      }
      toolResults.push({ id: tc.id, name: tc.name, output });
    }
    transcript.push({ role: 'tool_results', results: toolResults });
  }

  throw new Error(`최대 반복 횟수(${MAX_TURNS}회) 안에 보고서를 완성하지 못했습니다.`);
}

async function executeTool(name, input, tabId, domain) {
  switch (name) {
    case 'axe_scan':
      return sendToBackground({ type: 'RUN_AXE', tabId, options: input });
    case 'inspect_element':
      return sendToBackground({ type: 'INSPECT_ELEMENT', tabId, selector: input.selector });
    case 'verify_fix':
      return sendToBackground({ type: 'VERIFY_FIX', tabId, payload: input });
    case 'compute_contrast':
      return computeContrastLocally(input.foreground, input.background);
    case 'check_cache':
      return checkExplanationCache(domain, input.ruleId);
    case 'save_explanation_cache':
      return saveExplanationCache(domain, input);
    default:
      return { error: `알 수 없는 도구: ${name}` };
  }
}

// ── 규칙 ID + 도메인 단위 설명 캐시 (AI 재호출 없이 재사용) ─────
function cacheKey(domain, ruleId) {
  return `explainCache:${CACHE_VERSION}:${domain}:${ruleId}`;
}

async function checkExplanationCache(domain, ruleId) {
  return new Promise((resolve) => {
    const key = cacheKey(domain, ruleId);
    chrome.storage.local.get(key, (data) => {
      const entry = data[key];
      if (entry) {
        resolve({ cached: true, ...entry });
      } else {
        resolve({ cached: false });
      }
    });
  });
}

async function saveExplanationCache(domain, { ruleId, title, kwcagRef, explanation, howToFix }) {
  return new Promise((resolve) => {
    const key = cacheKey(domain, ruleId);
    const entry = { title, kwcagRef, explanation, howToFix, savedAt: new Date().toISOString() };
    chrome.storage.local.set({ [key]: entry }, () => resolve({ saved: true }));
  });
}

function getDomainFromUrl(url) {
  try {
    const u = new URL(url);
    return u.hostname || `${u.protocol}${u.pathname}`;
  } catch (e) {
    return 'unknown';
  }
}

async function sendToBackground(msg) {
  const response = await sendMessage(msg);
  if (!response.ok) throw new Error(response.error || '백그라운드 작업 실패');
  return response.result;
}

// WCAG 명도 대비 계산 (순수 계산, DOM 접근 불필요)
function computeContrastLocally(fg, bg) {
  const l1 = relativeLuminance(parseColor(fg));
  const l2 = relativeLuminance(parseColor(bg));
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  const ratio = (lighter + 0.05) / (darker + 0.05);
  return {
    ratio: Math.round(ratio * 100) / 100,
    passesAA_normalText: ratio >= 4.5,
    passesAA_largeText: ratio >= 3,
    passesAAA_normalText: ratio >= 7,
  };
}

function parseColor(str) {
  const rgbMatch = str.match(/rgba?\(([^)]+)\)/);
  if (rgbMatch) {
    const parts = rgbMatch[1].split(',').map((n) => parseFloat(n.trim()));
    return { r: parts[0], g: parts[1], b: parts[2] };
  }
  const hex = str.replace('#', '');
  const full = hex.length === 3 ? hex.split('').map((c) => c + c).join('') : hex;
  const int = parseInt(full, 16);
  return { r: (int >> 16) & 255, g: (int >> 8) & 255, b: int & 255 };
}

function relativeLuminance({ r, g, b }) {
  const [rs, gs, bs] = [r, g, b].map((c) => {
    const v = c / 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * rs + 0.7152 * gs + 0.0722 * bs;
}

function describeToolCall(name, input) {
  switch (name) {
    case 'axe_scan':
      return input.selector
        ? `"${input.selector}" 영역 접근성 검사 중...`
        : '페이지 전체 접근성 검사 중...';
    case 'inspect_element':
      return `"${input.selector}" 요소의 스타일/속성 확인 중...`;
    case 'compute_contrast':
      return `색상 대비 계산 중 (${input.foreground} / ${input.background})...`;
    case 'verify_fix':
      return `"${input.selector}" 수정안 임시 적용 후 검증 중...`;
    case 'check_cache':
      return `"${input.ruleId}" 규칙의 저장된 설명이 있는지 확인 중...`;
    case 'save_explanation_cache':
      return `"${input.ruleId}" 규칙 설명을 이 사이트에 저장 중...`;
    default:
      return `${name} 실행 중...`;
  }
}

function logAgentStep(toolName, text, done) {
  const li = document.createElement('li');
  li.className = `agent-log-item${done ? ' agent-log-item--done' : ''}`;
  li.innerHTML = `<span class="agent-log-item__icon">${done ? '✓' : '›'}</span><span>${escapeHtml(
    text
  )}</span>`;
  agentLogListEl.appendChild(li);
  agentLogCountEl.textContent = `(${agentLogListEl.children.length})`;
  setStatus(text);
}

// ── UI 유틸 ──────────────────────────────────────────────────
function setStatus(text) {
  statusEl.textContent = text;
}

function getActiveTab() {
  return new Promise((resolve, reject) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (chrome.runtime.lastError || !tabs[0]) {
        reject(new Error('활성 탭을 찾을 수 없습니다.'));
        return;
      }
      resolve(tabs[0]);
    });
  });
}

function sendMessage(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (response) => resolve(response));
  });
}

const DEFAULT_MODEL = {
  claude: 'claude-sonnet-5',
  gemini: 'gemini-3.6-flash',
  openai: 'gpt-5.5',
};

function getSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get(
      ['provider', 'claudeApiKey', 'claudeModel', 'geminiApiKey', 'geminiModel', 'openaiApiKey', 'openaiModel'],
      (data) => {
        const provider = data.provider || 'gemini';
        const keyByProvider = {
          claude: data.claudeApiKey,
          gemini: data.geminiApiKey,
          openai: data.openaiApiKey,
        };
        const modelByProvider = {
          claude: data.claudeModel,
          gemini: data.geminiModel,
          openai: data.openaiModel,
        };
        resolve({
          provider,
          apiKey: keyByProvider[provider] || '',
          model: modelByProvider[provider] || DEFAULT_MODEL[provider],
        });
      }
    );
  });
}

function renderSummary(findings) {
  const counts = { critical: 0, serious: 0, moderate: 0, minor: 0 };
  findings.forEach((f) => {
    if (counts[f.severity] !== undefined) counts[f.severity] += 1;
  });

  summaryEl.innerHTML = Object.entries(counts)
    .filter(([, count]) => count > 0)
    .map(([sev, count]) => `<span class="summary__chip">${SEVERITY_LABEL[sev]} ${count}</span>`)
    .join('');
  summaryEl.hidden = false;
}

function renderResults(findings, tabId) {
  resultsEl.innerHTML = '';

  findings.forEach((f, index) => {
    const card = document.createElement('details');
    card.className = 'card';
    if (index === 0) card.open = true;

    const severity = f.severity || 'minor';

    card.innerHTML = `
      <summary class="card__header">
        <span class="badge badge--${severity}">${SEVERITY_LABEL[severity] || severity}</span>
        <span class="card__title">${escapeHtml(f.title)}</span>
        ${f.verified ? '<span class="verified-badge" title="verify_fix로 검증됨">✓ 검증됨</span>' : ''}
        <span class="card__chevron" aria-hidden="true">▾</span>
      </summary>
      <div class="card__body">
        ${f.kwcagRef ? `<span class="card__ref">${escapeHtml(f.kwcagRef)}</span>` : ''}
        <p class="card__section-label">무엇이 문제인가요</p>
        <p class="card__text">${escapeHtml(f.explanation)}</p>
        <p class="card__section-label">어떻게 수정하나요</p>
        <p class="card__text">${escapeHtml(f.howToFix)}</p>
        ${
          f.selector
            ? `<div class="card__nodes"><div class="node-row">
                <code title="${escapeHtml(f.selector)}">${escapeHtml(f.selector)}</code>
                <button class="btn btn--ghost" type="button" data-selector="${escapeHtml(
                  f.selector
                )}">위치 표시</button>
              </div></div>`
            : ''
        }
      </div>
    `;

    card.querySelectorAll('button[data-selector]').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const selector = btn.getAttribute('data-selector');
        if (selector) sendMessage({ type: 'HIGHLIGHT_NODE', tabId, target: selector });
      });
    });

    resultsEl.appendChild(card);
  });
}

reportBtn.addEventListener('click', handleGenerateReport);

async function handleGenerateReport() {
  if (!lastFindings.length || !lastTabInfo) return;

  reportBtn.disabled = true;
  const originalLabel = reportBtn.textContent;

  try {
    const findingsWithEvidence = [];
    for (let i = 0; i < lastFindings.length; i++) {
      const f = lastFindings[i];
      reportBtn.textContent = `스크린샷 수집 중... (${i + 1}/${lastFindings.length})`;

      let screenshotDataUrl = null;
      if (f.selector) {
        try {
          const capture = await sendToBackground({
            type: 'CAPTURE_ELEMENT_SCREENSHOT',
            tabId: lastTabInfo.id,
            selector: f.selector,
          });
          screenshotDataUrl = capture.screenshotDataUrl || null;
        } catch (e) {
          console.warn('스크린샷 캡처 실패:', f.selector, e.message);
        }
      }
      findingsWithEvidence.push({ ...f, screenshotDataUrl });
    }

    reportBtn.textContent = '보고서 여는 중...';

    const { score, grade } = computeScoreAndGrade(lastFindings);
    const reportData = {
      generatedAt: new Date().toISOString(),
      pageUrl: lastTabInfo.url,
      pageTitle: lastTabInfo.title,
      score,
      grade,
      findings: findingsWithEvidence,
    };

    await new Promise((resolve) => {
      chrome.storage.local.set({ lastReport: reportData }, resolve);
    });

    chrome.tabs.create({ url: chrome.runtime.getURL('report.html') });
  } catch (err) {
    console.error(err);
    setStatus(`보고서 생성 오류: ${err.message}`);
  } finally {
    reportBtn.disabled = false;
    reportBtn.textContent = originalLabel;
  }
}

// 심각도 가중치 기반 준수 점수/등급 (공식 KWCAG 인증 점수가 아닌 자체 산정 지표입니다)
function computeScoreAndGrade(findings) {
  const weights = { critical: 10, serious: 5, moderate: 2, minor: 1 };
  const penalty = findings.reduce((sum, f) => sum + (weights[f.severity] || 1), 0);
  const score = Math.max(0, 100 - penalty);
  let grade = 'D';
  if (score >= 90) grade = 'A';
  else if (score >= 75) grade = 'B';
  else if (score >= 60) grade = 'C';
  return { score, grade };
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
