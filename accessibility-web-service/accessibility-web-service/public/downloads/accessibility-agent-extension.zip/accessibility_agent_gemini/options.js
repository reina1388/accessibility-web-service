const form = document.getElementById('settings-form');
const providerSelect = document.getElementById('provider');
const saveMsg = document.getElementById('save-msg');

const providerFields = {
  gemini: { block: 'block-gemini', key: 'gemini-key', model: 'gemini-model', keyStorage: 'geminiApiKey', modelStorage: 'geminiModel' },
  claude: { block: 'block-claude', key: 'claude-key', model: 'claude-model', keyStorage: 'claudeApiKey', modelStorage: 'claudeModel' },
  openai: { block: 'block-openai', key: 'openai-key', model: 'openai-model', keyStorage: 'openaiApiKey', modelStorage: 'openaiModel' },
};

function showProviderBlock(provider) {
  Object.values(providerFields).forEach((f) => {
    document.getElementById(f.block).classList.remove('active');
  });
  const active = providerFields[provider];
  if (active) document.getElementById(active.block).classList.add('active');
}

providerSelect.addEventListener('change', () => showProviderBlock(providerSelect.value));

document.addEventListener('DOMContentLoaded', () => {
  const storageKeys = ['provider'];
  Object.values(providerFields).forEach((f) => {
    storageKeys.push(f.keyStorage, f.modelStorage);
  });

  chrome.storage.local.get(storageKeys, (data) => {
    const provider = data.provider || 'gemini';
    providerSelect.value = provider;
    showProviderBlock(provider);

    Object.entries(providerFields).forEach(([, f]) => {
      if (data[f.keyStorage]) document.getElementById(f.key).value = data[f.keyStorage];
      if (data[f.modelStorage]) document.getElementById(f.model).value = data[f.modelStorage];
    });
  });
});

form.addEventListener('submit', (e) => {
  e.preventDefault();

  const toSave = { provider: providerSelect.value };
  Object.values(providerFields).forEach((f) => {
    toSave[f.keyStorage] = document.getElementById(f.key).value.trim();
    toSave[f.modelStorage] = document.getElementById(f.model).value;
  });

  chrome.storage.local.set(toSave, () => {
    saveMsg.textContent = '저장되었습니다.';
    setTimeout(() => {
      saveMsg.textContent = '';
    }, 2000);
  });
});

const CACHE_PREFIX = 'explainCache:';
const cacheCountEl = document.getElementById('cache-count');
const cacheMsgEl = document.getElementById('cache-msg');
const clearCacheBtn = document.getElementById('clear-cache-btn');

function refreshCacheCount() {
  chrome.storage.local.get(null, (data) => {
    const keys = Object.keys(data).filter((k) => k.startsWith(CACHE_PREFIX));
    cacheCountEl.textContent = keys.length;
  });
}

clearCacheBtn.addEventListener('click', () => {
  chrome.storage.local.get(null, (data) => {
    const keys = Object.keys(data).filter((k) => k.startsWith(CACHE_PREFIX));
    chrome.storage.local.remove(keys, () => {
      cacheMsgEl.textContent = `${keys.length}건의 캐시를 삭제했습니다.`;
      refreshCacheCount();
      setTimeout(() => {
        cacheMsgEl.textContent = '';
      }, 2500);
    });
  });
});

refreshCacheCount();
